from django.contrib import admin
from django.contrib.admin.models import LogEntry

# Register your models here.

