# monitoring/urls.py

from django.urls import path

urlpatterns = []  # Keep this even if it's empty!
