from django.apps import AppConfig


class MotionControlConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'motion_control'
